const Produto = require('../models/Produto');
const {Op} = require ('sequelize');
async function cadastrar(req, res) {
    try {
        const produto = await Produto.create(req.body);
        res.status(201).json(produto);
    } catch (erro) {
        res.status(400).json({
            mensagem: 'Erro ao cadastrar produto',
            erro: erro.message,
        });
    }
}

async function listar(req, res) {
    try {
        const { pagina = 1, limite = 10, nome, data } = req.query;
        const filtro = {};

        if (nome) {
            filtro.titulo = { [Op.like]: `%${nome}%` };
        }

        const produtos = await Produto.findAll({
            where: filtro,
            limit: Number(limite),
            offset: (Number(pagina) - 1) * Number(limite),
        });

        res.json(produtos);
    } catch (erro) {
        res.status(400).json({
            mensagem: 'Erro ao listar produtos]',
            erro: erro.message,
        });
    }
}

async function deletar(req, res) {
    try {
        const { id } = req.params;

        const produto = await Produto.findByPk(id);

        if (!produto) {
            return res.status(404).json({
                mensagem: 'Produto nao encontrado',
            });
        }

        await livro.destroy();

        res.status(200).json({
            mensagem: 'Produto removido com sucesso',
        });

    } catch (erro) {
        res.status(400).json({
            mensagem: 'Erro ao deletar Produto',
            erro: erro.message,
        });
    }
}

module.exports = {cadastrar, listar, deletar};
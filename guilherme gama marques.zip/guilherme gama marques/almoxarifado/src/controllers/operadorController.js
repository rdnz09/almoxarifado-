const bcrypt = require('bcrypt');
const Operador = require('../models/Operador');
const { Op } = require('sequelize');

async function cadastrar(req, res) {
  try {
    const {
      nome,
      email,
      senha,
      telefone,
    } = req.body;

    if (
      !nome ||
      !email ||
      !senha ||
      !telefone
    ) {
      return res.status(400).json({
        mensagem: 'Todos os campos são obrigatórios'
      });
    }

    const operadorExistente = await Operador.findOne({
      where: {
        [Op.or]: [{ email }, { placa }]
      }
    });

    if (operadorExistente) {
      return res.status(409).json({
        mensagem: 'Email ou placa já cadastrados'
      });
    }

    const senhaHash = await bcrypt.hash(senha, 10);

    const operador = await Operador.create({
      nome,
      email,
      senha: senhaHash,
      telefone,
    });

    return res.status(201).json({
      mensagem: 'Operador cadastrado com sucesso',
      operador: {
        id: operador.id,
        nome: operador.nome,
        email: operador.email,
        telefone: operador.telefone,
      }
    });

  } catch (erro) {
    return res.status(500).json({
      mensagem: 'Erro ao cadastrar operador',
      erro: erro.message
    });
  }
}

async function perfil(req, res) {
  try {
    const operador = await Cliente.findByPk(req.operador.id, {
      attributes: {
        exclude: ['senha']
      }
    });

    if (!operador) {
      return res.status(404).json({
        mensagem: 'Operador não encontrado'
      });
    }

    return res.json(operador);

  } catch (erro) {
    return res.status(500).json({
      mensagem: 'Erro ao buscar perfil',
      erro: erro.message
    });
  }
}

module.exports = {
  cadastrar,
  perfil
};
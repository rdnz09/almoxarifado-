const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Livro = require('./Produto');
const Usuario = require('./Adm');

const Movimentacao = sequelize.define('Movimentacao', {
  tipo: {
    type: DataTypes.ENUM('entrada', 'saida'),
    allowNull: false,
  },
  quantidade: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
    },
  },
  data: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
});

Livro.hasMany(Movimentacao, { foreignKey: 'produto_id' });
Movimentacao.belongsTo(Livro, { foreignKey: 'produto_id' });
Usuario.hasMany(Movimentacao, { foreignKey: 'adm_id' });
Movimentacao.belongsTo(Usuario, { foreignKey: 'adm_id' });

module.exports = Movimentacao;

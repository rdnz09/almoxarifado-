const { DataTypes } = require('sequelize');

const sequelize = require('../config/database');
const Produto = sequelize.define('Produto', {
titulo: {
type: DataTypes.STRING,
allowNull: false,
},
autor: {
type: DataTypes.STRING,
allowNull: false,
},
quantidade_estoque: {
type: DataTypes.INTEGER,
allowNull: false,
defaultValue: 0,
},
});
module.exports = Produto;
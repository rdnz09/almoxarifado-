const express = require('express');
const router = express.Router();
const { cadastrar, listar, deletar } = require('../controllers/produtoController');
const auth = require('../middlewares/auth');
const permitir = require('../middlewares/checkRole');
router.post('/produto', auth, cadastrar);
router.get('/produto', auth, listar);
router.delete('/produto/:id', auth, permitir('administrador'), deletar);
module.exports = router;
const express = require('express');
const router = express.Router();

const { cadastrar } = require('../controllers/admController');

router.post('/adm', cadastrar);

module.exports = router;
const express = require('express');
const {
  cadastrar,
  perfil
} = require('../controllers/operadorController');

const autenticar = require('../middlewares/auth');

const router = express.Router();

router.post('/operador', cadastrar);

router.get(
  '/operador/perfil',
  autenticar,
  perfil
);

module.exports = router;